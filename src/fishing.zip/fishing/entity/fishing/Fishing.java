package fishing.entity.fishing;

import fishing.entity.site.Site;

public interface Fishing {

    void startFishing(Site site);
}
